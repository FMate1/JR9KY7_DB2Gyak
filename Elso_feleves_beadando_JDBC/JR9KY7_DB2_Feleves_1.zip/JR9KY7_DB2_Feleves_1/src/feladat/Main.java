package feladat;

//Import
import java.sql.*;
import java.util.ArrayList;


public class Main {
	
	//URL
	private static final String URL = "jdbc:oracle:thin:@193.6.5.58:1521:XE";
	
	//ArrayList file-ba �r�shoz
	static ArrayList<String> dataForTxt = new ArrayList<String>();

	//Main
	public static void main(String[] args) {
		
		try {
			
			Connection conn = connect("H22_JR9KY7","JR9KY7");
			
			//Functions.createTables(conn); 								//T�bl�k l�trehoz�sa
			//Functions.insertPincer(conn); 								//Pinc�r t�bla felt�lt�se
			//Functions.insertAsztal(conn); 								//Asztal t�bla felt�lt�se
			//Functions.insertRendeles(conn); 								//Rendel�s t�bla felt�lt�se
			//Functions.insertHozzavalo(conn); 								//Hozz�val�  t�bla felt�lt�se
			//Functions.insertTartalmaz(conn); 								//Tartalmaz t�bla felt�lt�se
			//Functions.addVegosszeg(conn); 								//Rendel�s t�bl�hoz v�g�sszeg mez� hozz�ad�sa
			//Functions.updateVegosszeg(conn); 								//Rendel�s t�bl�ban szerepl� v�g�sszeg mez�nek �rt�kad�sa
			//Functions.deleteByIdFromPincer(conn, 4); 						//Pinc�r t�bl�b�l val� t�rl�s ID alapj�n
			//Functions.getDBMetadata(conn); 								//Adatb�zis metadata lek�rdez�se
			//Functions.selectAvgVegosszeg(conn); 							//A v�g�sszegek �tlag�r�nak kisz�m�t�sa
			//Functions.getAllRendelesMeta(conn); 							//A rendel�sel t�bla metadata
			//Functions.getAllPincerMeta(conn); 							//A pinc�r t�bla metadata
			//Functions.selectAsztalRendeles(conn); 						//Asztalok �s a hozz� tartoz� v�g�sszeg
			//Functions.selectMaxFizuPincerAsztalRendeles(conn); 			//Azon asztalok, ahol a legmagasabb fizet�s� pinc�r szolg�l fel
			//Functions.selectPincerByName(conn, "Lukacs Balazs"); 			//Pinc�r adatainak lek�r�se n�v alapj�n
			//Functions.selectAsztalByFerohely(conn, 2); 					//Asztalok felsorol�sa f�r�hely alapj�n
			//Functions.selectRendelesVegosszegByHozzavalo(conn, "tej");	//Rendel�ssz�m �s v�g�sszeg keres�se felhaszn�lt hozz�val� alapj�n
			//Functions.pincerFizetesModositas(conn, 270000, 2);			//Pinc�r fizet�s�nek m�dos�t�sa ID alapj�n
			
			// File-ba �r�s	
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM Pincer");
						 
			while (rs.next()) {
				String pincerID = rs.getString(1);
				String nev = rs.getString(2);
				String fizetes = rs.getString(3);
				String kor = rs.getString(4);
				String kezdes = rs.getString(5);

				dataForTxt.add(pincerID + " " + nev + " " + fizetes + " "+ kor + " " + kezdes );
			}
			Functions.writeToFile(dataForTxt, "Pincerek.txt");
			rs.close();
			stmt.close(); 
			
			System.out.println("Megy!");
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	} //end main
	
	//Connection
	public static Connection connect(String username, String password) throws ClassNotFoundException, SQLException {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");			
		Connection conn = DriverManager.getConnection(URL, username, password);
		return conn;
	} //end connect

} //end class
