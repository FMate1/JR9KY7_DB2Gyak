package feladat;

public class Lekerdezes2 {
	
	private int asztalszam;
	private int ferohely;
	private int emelet;
	private int rendelesszam;
	private int vegosszeg;
	
	public Lekerdezes2(int asztalszam, int ferohely, int emelet, int rendelesszam, int vegosszeg) {
		super();
		this.asztalszam = asztalszam;
		this.ferohely = ferohely;
		this.emelet = emelet;
		this.rendelesszam = rendelesszam;
		this.vegosszeg = vegosszeg;
	}

	public int getAsztalszam() {
		return asztalszam;
	}

	public void setAsztalszam(int asztalszam) {
		this.asztalszam = asztalszam;
	}

	public int getFerohely() {
		return ferohely;
	}

	public void setFerohely(int ferohely) {
		this.ferohely = ferohely;
	}

	public int getEmelet() {
		return emelet;
	}

	public void setEmelet(int emelet) {
		this.emelet = emelet;
	}

	public int getRendelesszam() {
		return rendelesszam;
	}

	public void setRendelesszam(int rendelesszam) {
		this.rendelesszam = rendelesszam;
	}

	public int getVegosszeg() {
		return vegosszeg;
	}

	public void setVegosszeg(int vegosszeg) {
		this.vegosszeg = vegosszeg;
	}

	@Override
	public String toString() {
		return "asztalszam = " + asztalszam + ", ferohely = " + ferohely + ", emelet = " + emelet
				+ ", rendelesszam = " + rendelesszam + ", vegosszeg = " + vegosszeg + "\n";
	}
	
} //end class
