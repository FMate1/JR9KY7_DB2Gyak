package feladat;

public class Pincer {
	
	private int pincerID;
	private String nev;
	private int fizetes;
	private int kor;
	private String kezdes;
	
	public Pincer(int pincerID, String nev, int fizetes, int kor, String kezdes) {
		super();
		this.pincerID = pincerID;
		this.nev = nev;
		this.fizetes = fizetes;
		this.kor = kor;
		this.kezdes = kezdes;
	}

	public int getPincerID() {
		return pincerID;
	}

	public void setPincerID(int pincerID) {
		this.pincerID = pincerID;
	}

	public String getNev() {
		return nev;
	}

	public void setNev(String nev) {
		this.nev = nev;
	}

	public int getFizetes() {
		return fizetes;
	}

	public void setFizetes(int fizetes) {
		this.fizetes = fizetes;
	}

	public int getKor() {
		return kor;
	}

	public void setKor(int kor) {
		this.kor = kor;
	}

	public String getKezdes() {
		return kezdes;
	}

	public void setKezdes(String kezdes) {
		this.kezdes = kezdes;
	}

	@Override
	public String toString() {
		return "Pincer: " + pincerID + " " + nev + " " + fizetes + " " + kor + " " + kezdes + "\n";
	}

} //end class
