package feladat;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Functions {

	public static void createTables(Connection conn) throws SQLException {
		Statement stmt1 = conn.createStatement(); //Pinc�r t�bla
		Statement stmt2 = conn.createStatement(); //Asztal t�bla
		Statement stmt3 = conn.createStatement(); //Rendel�s t�bla
		Statement stmt4 = conn.createStatement(); //Hozz�val� t�bla
		Statement stmt5 = conn.createStatement(); //Tartalmaz t�bla
		
		stmt1.execute("CREATE TABLE Pincer (pincerID int primary key, nev varchar(45), fizetes int check(fizetes > 200000), kor int check(kor >= 18), kezdes char(10) not null)");
		stmt2.execute("CREATE TABLE Asztal (asztalszam int primary key, ferohely int check(ferohely > 1), emelet int, foglalt int default 0, pincerAZ int, foreign key (pincerAZ) references Pincer(pincerID))");
		stmt3.execute("CREATE TABLE Rendeles (rendelesszam int primary key, etelDB int check(etelDB >= 0), italDB int check(italDB >= 0), etelar int check(etelar >= 0), italar int check(italar >= 0), asztalszam int, foreign key (asztalszam) references Asztal(asztalszam))");
		stmt4.execute("CREATE TABLE Hozzavalo (hozzavaloID int primary key, nev varchar(30), darabszam int check(darabszam >= 0), allergen varchar(20))");
		stmt5.execute("CREATE TABLE Tartalmaz (rendelesszam int, hozzavaloID int, foreign key (rendelesszam) references Rendeles(rendelesszam), foreign key (hozzavaloID) references Hozzavalo(hozzavaloID))");
		
		stmt1.close();
		stmt2.close();
		stmt3.close();
		stmt4.close();
		stmt5.close();
		
		System.out.println("Tablak letrehozva!\n");
	} //end createTables
	
	public static void insertPincer(Connection conn) throws SQLException {
		Statement stmt = conn.createStatement();
		
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Pincer VALUES (1, 'Szabo Laszlo', 320000, 36, '2006-02-12')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Pincer VALUES (2, 'Kovacs Istvan', 230000, 27, '2010-05-19')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Pincer VALUES (3, 'Lukacs Balazs', 260000, 21, '2014-10-05')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Pincer VALUES (4, 'Almasi Kristof', 260100, 20, '2019-11-25')"));

		stmt.close();
		
		System.out.println("Pincer tabla feltoltve!\n");
	} //end insertPincer
	
	public static void insertAsztal(Connection conn) throws SQLException {
		Statement stmt = conn.createStatement();
		
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (1, 6, 0, 0, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (2, 2, 1, 1, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (3, 2, 1, 1, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (4, 10, 0, 0, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (5, 4, 0, 1, 2)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (6, 4, 1, 1, 2)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (7, 8, 0, 0, 2)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (8, 4, 0, 0, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (9, 2, 1, 1, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (10, 2, 1, 1, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (11, 8, 0, 1, 2)"));
		
		stmt.close();
		
		System.out.println("Asztal tabla feltoltve!\n");
	} //end insertAsztal
	
	public static void insertRendeles(Connection conn) throws SQLException {
		Statement stmt = conn.createStatement();
		
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (1, 2, 4, 3000, 500, 2)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (2, 2, 2, 5000, 600, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (3, 0, 4, 0, 800, 5)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (4, 4, 0, 2800, 0, 6)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (5, 0, 4, 0, 1300, 9)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (6, 2, 6, 10000, 750, 10)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (7, 8, 12, 4600, 750, 11)"));
		
		stmt.close();
		
		System.out.println("Rendeles tabla feltoltve!\n");
	} //end insertRendeles
	
	public static void insertHozzavalo(Connection conn) throws SQLException {
		Statement stmt = conn.createStatement();
		
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (1, 'teszta', 20, 'gluten')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (2, 'tej', 20, 'laktoz')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (3, 'vaj', 32, 'laktoz')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (4, 'liszt', 32, 'gluten')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (5, 'liszt', 15, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (6, 'marhahus', 23, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (7, 'csirkehus', 35, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (8, 'vadhus', 27, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (9, 'rizs', 36, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (10, 'burgonya', 21, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (11, 'alkohol', 70, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (12, 'alkohol mentes', 70, NULL)"));
		
		stmt.close();
		
		System.out.println("Hozzavalo tabla feltoltve!\n");
	} //end insertHozzavalo
	
	public static void insertTartalmaz(Connection conn) throws SQLException {
		Statement stmt = conn.createStatement();
		
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 4)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 7)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 9)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 12)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (2, 8)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (2, 10)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (2, 11)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (3, 11)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (3, 12)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (4, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (4, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (4, 7)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (4, 9)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (4, 2)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (5, 11)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 12)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 11)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 10)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 8)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 5)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 9)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 7)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 4)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 6)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 7)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 8)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 9)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 10)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 11)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 12)"));
		
		stmt.close();
		
		System.out.println("Tartalmaz tabla feltoltve!\n");
	} //end insertTartalmaz
	
	public static void addVegosszeg(Connection conn) throws SQLException {
		
		Statement stmt = conn.createStatement();
		stmt.executeUpdate("ALTER TABLE Rendeles ADD vegosszeg int");
		stmt.close();
		
		System.out.println("Vegosszeg mezo hozzaadva!\n");
	} //end addVegosszeg
	
	public static void updateVegosszeg(Connection conn) throws SQLException {	
		
		Statement stmt = conn.createStatement();
		stmt.executeUpdate("UPDATE Rendeles SET vegosszeg = (etelDB * etelar) + (italDB * italar)");
		stmt.close();
		
		System.out.println("Vegosszeg mezo frissitve!\n");
	} //end updateVegosszeg
	
	public static void deleteByIdFromPincer(Connection conn, int id) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("DELETE FROM Pincer WHERE pincerID=?");
		prstmt.setInt(1, id);
		System.out.println("Deleted waiter: "+ prstmt.executeUpdate());
		prstmt.close();
		
		System.out.println("Item deleted!\n");
	} //end deleteByIdFromPincer
	
	public static void getDBMetadata(Connection conn) throws SQLException {
		
		System.out.println("Driver verzi�: " + conn.getMetaData().getDriverVersion());
		String[] specifyTables= {"TABLE"};
		ResultSet rs= conn.getMetaData().getTables(null, null, "%", specifyTables);
		while(rs.next()) {
			System.out.println(rs.getString(3));
		}
		rs.close();
	} //end getDBMetadata
	
	public static void writeToFile(java.util.List<String> list, String path) {
		
        BufferedWriter out = null;
        try {
            File file = new File(path);
            out = new BufferedWriter(new FileWriter(file, true));
            for (Object s : list) {
                out.write((String) s);
                out.newLine();
            }
            out.flush();
            out.close();
            
            System.out.println("File-ba iras sikeres!\n");
        } catch (IOException e) {
        	System.out.println(e);
        }
    } //end writeToFile
	
	public static void selectAvgVegosszeg(Connection conn) throws SQLException {
		
		int avg = 0;
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT AVG(vegosszeg) AS atlagvego FROM Rendeles");
		while(rs.next()) {
			avg = rs.getInt("atlagvego");
        }
		stmt.close();
		rs.close();

		System.out.println("A rendelesek vegosszegenek atlaga: " + avg + " Ft");
	} //end selectAvgVegosszeg
	
	public static void getAllRendelesMeta(Connection conn) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT * FROM Rendeles");
		ResultSet rs = prstmt.executeQuery();	
		ResultSetMetaData rsmd = rs.getMetaData();
		System.out.println("Mezok szama rendeles eseten: " + rsmd.getColumnCount());
		for (int i = 1; i <= rsmd.getColumnCount(); i++) {
			System.out.println(rsmd.getColumnName(i)+":"+ rsmd.getColumnTypeName(i));
		}
		prstmt.close();
		rs.close();
	} //end getAllRendelesMeta
	
	public static void getAllPincerMeta(Connection conn) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT * FROM Pincer");
		ResultSet rs = prstmt.executeQuery();	
		ResultSetMetaData rsmd = rs.getMetaData();
		System.out.println("Mezok szama pincerek eseten: " + rsmd.getColumnCount());
		for (int i = 1; i <= rsmd.getColumnCount(); i++) {
			System.out.println(rsmd.getColumnName(i)+":"+ rsmd.getColumnTypeName(i));
		}
		prstmt.close();
		rs.close();
	} //end getAllRendelesMeta
	
	public static void selectAsztalRendeles(Connection conn) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT Asztal.asztalszam, Rendeles.vegosszeg FROM Asztal INNER JOIN Rendeles ON Asztal.asztalszam = Rendeles.asztalszam");
		ResultSet rs = prstmt.executeQuery();
		List <Lekerdezes1> adatokLista = new ArrayList<>();
		while(rs.next()) {
			Lekerdezes1 adat = new Lekerdezes1(rs.getInt("asztalszam"), rs.getInt("vegosszeg"));
			adatokLista.add(adat);
			System.out.println(adat);
		}
		
		prstmt.close();
		rs.close();
	} //end selectAsztalRendeles
	
	public static void selectMaxFizuPincerAsztalRendeles(Connection conn) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT Asztal.asztalszam, Asztal.ferohely, Asztal.emelet, Rendeles.rendelesszam, Rendeles.vegosszeg FROM Asztal INNER JOIN Rendeles ON Asztal.asztalszam = Rendeles.asztalszam WHERE Asztal.pincerAZ = (SELECT Pincer.pincerID FROM Pincer WHERE Pincer.fizetes = (SELECT MAX(fizetes) FROM Pincer))");
		ResultSet rs = prstmt.executeQuery();
		List <Lekerdezes2> adatokLista = new ArrayList<>();
		while(rs.next()) {
			Lekerdezes2 adat = new Lekerdezes2(rs.getInt("asztalszam"),rs.getInt("ferohely"), rs.getInt("emelet"),rs.getInt("rendelesszam"), rs.getInt("vegosszeg"));
			adatokLista.add(adat);
			System.out.println(adat);
		}
		
		prstmt.close();
		rs.close();
	} //end selectMaxFizuPincerAsztalRendeles
	
	public static void selectPincerByName(Connection conn,String nev) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT * FROM Pincer WHERE nev = ?");
		prstmt.setString(1, nev);
		ResultSet rs = prstmt.executeQuery();
		List<Pincer> pincerLista = new ArrayList<>();
		while(rs.next()) {
			Pincer pincer = new Pincer(rs.getInt("pincerID"),rs.getString("nev"),rs.getInt("fizetes"),rs.getInt("kor"),rs.getString("kezdes"));
			pincerLista.add(pincer);
			
			System.out.println(pincer);
		}
		rs.close();
		prstmt.close();
	} //end selectPincerByName
	
	public static void selectAsztalByFerohely(Connection conn,int ferohelyszam) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT * FROM Asztal WHERE ferohely = ?");
		prstmt.setInt(1, ferohelyszam);
		ResultSet rs = prstmt.executeQuery();
		List<Asztal> asztalLista = new ArrayList<>();
		while(rs.next()) {
			Asztal asztal = new Asztal(rs.getInt("asztalszam"),rs.getInt("ferohely"),rs.getInt("emelet"),rs.getInt("pincerAZ"));
			asztalLista.add(asztal);
			
			System.out.println(asztal);
		}
		rs.close();
		prstmt.close();
	} //end selectAsztalByFerohely
	
	public static void selectRendelesVegosszegByHozzavalo(Connection conn,String hozzavaloNeve) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT rendelesszam, vegosszeg FROM Rendeles WHERE rendelesszam IN (SELECT rendelesszam FROM Tartalmaz WHERE hozzavaloID = (SELECT hozzavaloID FROM Hozzavalo WHERE nev = ?))");
		prstmt.setString(1, hozzavaloNeve);
		ResultSet rs = prstmt.executeQuery();
		List<Lekerdezes3> adatokLista = new ArrayList<>();
		while(rs.next()) {
			Lekerdezes3 adat = new Lekerdezes3(rs.getInt("rendelesszam"),rs.getInt("vegosszeg"));
			adatokLista.add(adat);
			
			System.out.println(adat);
		}
		rs.close();
		prstmt.close();
	} //end selectRendelesVegosszegByHozzavalo
	
	//pincerFizetesemeles
	
	public static void pincerFizetesModositas(Connection conn, int ujFiz, int pincerID) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("UPDATE Pincer SET fizetes = ? WHERE pincerID = ?");
		prstmt.setInt(1, ujFiz);
		prstmt.setInt(2, pincerID);
		
		prstmt.executeUpdate();
		prstmt.close();
		
		System.out.println("Pincer fizetes updated!\n");
	} //end pincerFizetesModositas

} //end class