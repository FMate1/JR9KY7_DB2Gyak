package feladat;

public class Lekerdezes1 {

	private int asztalszam;
	private int vegosszeg;
	
	public Lekerdezes1(int asztalszam, int vegosszeg) {
		super();
		this.asztalszam = asztalszam;
		this.vegosszeg = vegosszeg;
	}

	public int getAsztalszam() {
		return asztalszam;
	}

	public void setAsztalszam(int asztalszam) {
		this.asztalszam = asztalszam;
	}

	public int getVegosszeg() {
		return vegosszeg;
	}

	public void setVegosszeg(int vegosszeg) {
		this.vegosszeg = vegosszeg;
	}

	@Override
	public String toString() {
		return "asztalszam = " + asztalszam + ", vegosszeg = " + vegosszeg + "\n";
	}
		
} //end class
