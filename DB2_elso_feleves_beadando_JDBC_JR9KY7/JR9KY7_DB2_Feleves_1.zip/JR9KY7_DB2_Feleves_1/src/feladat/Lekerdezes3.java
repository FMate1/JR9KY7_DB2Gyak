package feladat;

public class Lekerdezes3 {
	
	private int rendelesszam;
	private int vegosszeg;
	
	public Lekerdezes3(int rendelesszam, int vegosszeg) {
		super();
		this.rendelesszam = rendelesszam;
		this.vegosszeg = vegosszeg;
	}

	public int getRendelesszam() {
		return rendelesszam;
	}

	public void setRendelesszam(int rendelesszam) {
		this.rendelesszam = rendelesszam;
	}

	public int getVegosszeg() {
		return vegosszeg;
	}

	public void setVegosszeg(int vegosszeg) {
		this.vegosszeg = vegosszeg;
	}

	@Override
	public String toString() {
		return "Lekerdezes: rendelesszam = " + rendelesszam + ", vegosszeg = " + vegosszeg + "\n";
	}

} //end class
