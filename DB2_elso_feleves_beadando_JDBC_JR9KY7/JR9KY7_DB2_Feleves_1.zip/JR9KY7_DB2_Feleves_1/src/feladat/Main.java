package feladat;

//Import
import java.sql.*;
import java.util.ArrayList;


public class Main {
	
	//Felhasznalo navigalasa
	private static boolean nextRound_main = true;
	private static boolean nextRound_meta = true;
	private static boolean nextRound_lekerdezes = true;
	private static boolean nextRound_insert = true;
	private static int userChoice;
	
	//ArrayList file-ba irashoz
	static ArrayList<String> dataForTxt = new ArrayList<String>();

	//Main
	public static void main(String[] args) {    
        
		try {
			Connection conn = Functions.connect();
			
			while(nextRound_main) {
				
				nextRound_meta = true;
				nextRound_lekerdezes = true;
				nextRound_insert = true;
			
				userChoice = Functions.menu();
			
				switch (userChoice) {
				case 1: //create table
					Functions.createTables(conn);										//T�bl�k l�trehoz�sa
					break;
					
				case 2: //auto insert	
					Functions.insertPincer(conn); 										//Pincer tabla feltoltese
					Functions.insertAsztal(conn); 										//Asztal tabla feltoltese
					Functions.insertRendeles(conn); 									//Rendeles tabla feltoltese
					Functions.insertHozzavalo(conn); 									//Hozzavalo  tabla feltoltese
					Functions.insertTartalmaz(conn); 									//Tartalmaz tabla feltoltese
					break;
					
				case 3: //rendeles add/update
					Functions.addVegosszeg(conn);										//Rendeles tablahoz vegosszeg mezo hozzaadasa
					Functions.updateVegosszeg(conn); 									//Rendelas tablaban szereplo vegosszeg mezonek ertekadasa
					break;
					
				case 4: //delete pincer by id
					Functions.deleteByIdFromPincer(conn, 4); 							//Pincer tablabol valo torles ID alapjan
					break;
					
				case 5:	//Adatbazis metadata lekerdezese
					Functions.getDBMetadata(conn); 										
					break;
					
				case 6: //write to file
					Statement stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery("SELECT * FROM Pincer");
								 
					while (rs.next()) {
						String pincerID = rs.getString(1);
						String nev = rs.getString(2);
						String fizetes = rs.getString(3);
						String kor = rs.getString(4);
						String kezdes = rs.getString(5);

						dataForTxt.add(pincerID + " " + nev + " " + fizetes + " "+ kor + " " + kezdes );
					}
					Functions.writeToFile(dataForTxt, "Pincerek.txt");
					rs.close();
					stmt.close(); 
					break;
					
				case 7: //tabla meta menu
					while(nextRound_meta) {
					userChoice = Functions.menuTablaMeta();
						switch (userChoice) {
						case 1:	//A rendelesel tabla metadata
							Functions.getAllRendelesMeta(conn); 						
							nextRound_meta = false;
							break;
							
						case 2:	//A pincer tabla metadata
							Functions.getAllPincerMeta(conn); 							
							nextRound_meta = false;
							break;
							
						case 3: //back
							nextRound_meta = false;
							break;

						default:
							break;
						}
					} //end while meta
					break;
					
				case 8: //select menu
					while(nextRound_lekerdezes) {
					userChoice = Functions.menuLekerdezes();
						switch (userChoice) {
						case 1:	//A vegosszegek atlagaranak kiszamitasa
							Functions.selectAvgVegosszeg(conn); 						
							nextRound_lekerdezes = false;
							break;	
							
						case 2:	//Asztalok es a hozza tartozo vegosszeg
							Functions.selectAsztalRendeles(conn); 						
							nextRound_lekerdezes = false;
							break;
							
						case 3:	//Azon asztalok, ahol a legmagasabb fizetesu pincer szolgal fel
							Functions.selectMaxFizuPincerAsztalRendeles(conn); 			
							nextRound_lekerdezes = false;
							break;
							
						case 4:	//Pincer adatainak lekerese nev alapjan
							Functions.selectPincerByName(conn, "Lukacs Balazs"); 
							nextRound_lekerdezes = false;
							break;
							
						case 5:	//Asztalok felsorol�sa ferohely alapjan
							Functions.selectAsztalByFerohely(conn, 2); 					
							nextRound_lekerdezes = false;
							break;
							
						case 6:	//Rendelesszam �s vegosszeg keresese felhasznalt hozzavalo alapjan
							Functions.selectRendelesVegosszegByHozzavalo(conn, "tej");	
							nextRound_lekerdezes = false;
							break;
							
						case 7: //back
							nextRound_lekerdezes = false;
							break;
						
						default:
							break;
						} //end switch menuLekerdezes
					} //end while lekerd
					break;
					
				case 9: //pincer fiz update by ID
					Functions.pincerFizetesModositas(conn, 270000, 2);
					break;
					
				case 10: //pincer fiz update by ID user input
					Functions.pincerFizetesModUser(conn);
					break;
					
				case 11: //uj rekord felvetele user inputrol menu
			
					while(nextRound_insert) {
					userChoice = Functions.menuInsert();
						switch (userChoice) {
						case 1:	//Insert pincer tabla
							Functions.insertPincerFromUser(conn);
							nextRound_insert = false;
							break;	
								
						case 2:	//Insert asztal tabla
							Functions.insertAsztalFromUser(conn);
							nextRound_insert = false;
							break;
								
						case 3:	//Insert rendeles tabla
							Functions.insertRendelesFromUser(conn);
							nextRound_insert = false;
							break;
								
						case 4:	//Insert hozzavalo tabla
							Functions.insertHozzavaloFromUser(conn);
							nextRound_insert = false;
							break;
								
						case 5:	//Insert tartalmaz tabla
							Functions.insertTartalmazFromUser(conn);
							nextRound_insert = false;
							break;
								
						case 6: //back
							nextRound_insert = false;
							break;
							
						default:
							break;
						} //end switch menuInsert
					} //end while insert
						break;
					
				case 12: //exit
					System.out.println("Adios!");
					nextRound_main = false;
					break;

				default:
					break;
				} //end main switch
			} //end while nextRound_main
			
			System.out.println("Lefutott YEE!");
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	} //end main	

} //end class