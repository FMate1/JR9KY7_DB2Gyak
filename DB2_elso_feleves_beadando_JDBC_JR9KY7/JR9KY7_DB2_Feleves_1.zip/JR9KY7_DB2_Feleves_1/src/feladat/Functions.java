package feladat;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Functions {
	
	//Valtozok
	private static int selection;
	private static Scanner input;
	
	//URL
	private static final String URL = "jdbc:oracle:thin:@193.6.5.58:1521:XE";
	
	//Connection
	public static Connection connect() throws ClassNotFoundException, SQLException {
		
		String username = "";
		String password = "";
		input = new Scanner(System.in);
		System.out.println("Kerem adja meg a felhasznalonevet!");
		username = input.nextLine(); //H22_JR9KY7
		System.out.println("Kerem adja meg a jeszavat!");
		password = input.nextLine(); //JR9KY7
		
		Class.forName("oracle.jdbc.driver.OracleDriver");			
		Connection conn = DriverManager.getConnection(URL, username, password);
		return conn;
	} //end connect
	
	//Main menu
	public static int menu() {
		
	    input = new Scanner(System.in);

	    System.out.println("\nValasszon a lehetosegekbol");
	    System.out.println("-------------------------\n");
	    System.out.println("1 - Tablak letrehozasa");
	    System.out.println("2 - Tablak automatikus feltoltese");
	    System.out.println("3 - Rendeles tabla kiegeszitese");
	    System.out.println("4 - Torles pincer tablabol ID alapjan");
	    System.out.println("5 - Adatbazis metadata lekerdezese");
	    System.out.println("6 - Fajlba iras");
	    System.out.println("7 - Tabla metadata");
	    System.out.println("8 - Lekerdezesek");
	    System.out.println("9 - Pincer fizetes modositas ID alapjan");
	    System.out.println("10 - Pincer fizetes modositas user inputrol ID alapjan");
	    System.out.println("11 - Insert felhasznalotol");
	    System.out.println("12 - Kilepes");

	    selection = input.nextInt();
	    return selection;    
	} // end menu
		
	//Tabla metadata menu
	public static int menuTablaMeta() {

	    input = new Scanner(System.in);

	    System.out.println("\nValasszon a tablakbol");
	    System.out.println("-------------------------\n");
	    System.out.println("1 - Rendeles tabla");
	    System.out.println("2 - Pincer tabla");
	    System.out.println("3 - Vissza");

	    selection = input.nextInt();
	    return selection;    
    } // end menuTablaMeta 
	
	//Lekerdezes menu
	public static int menuLekerdezes() {
			
		input = new Scanner(System.in);

		System.out.println("\nValasszon a lekerdezesekbol");
		System.out.println("-------------------------\n");
		System.out.println("1 - Vegosszegek atlaga");
		System.out.println("2 - Asztalok es hozza tartozo rendelesek");
		System.out.println("3 - Asztalok es rendelesek amit/ahol a legmagasabb fizetesu pincer szolgal fel");
		System.out.println("4 - Pincer lekerdezese nev alapjan");
		System.out.println("5 - Asztalok listazasa ferohely alapjan");
		System.out.println("6 - Rendeles es vegosszeg, amelyhez megadott hozzavalot hasznaltak fel");
		System.out.println("7 - Vissza");

		selection = input.nextInt();
		return selection;    
	} // end menuLekerdezes
	
	//Insert menu
	public static int menuInsert() {
		input = new Scanner(System.in);

		System.out.println("\nValasszon a tablakbol, ahova adatot vinne fel");
		System.out.println("-------------------------\n");
		System.out.println("1 - Pincer");
		System.out.println("2 - Asztal");
		System.out.println("3 - Rendeles");
		System.out.println("4 - Hozzavalo");
		System.out.println("5 - Tartalmaz");
		System.out.println("6 - Vissza");

		selection = input.nextInt();
		return selection;    
	} //end menuInsert

	//Create Tables
	public static void createTables(Connection conn) throws SQLException {
		Statement stmt1 = conn.createStatement(); //Pincer tabla
		Statement stmt2 = conn.createStatement(); //Asztal tabla
		Statement stmt3 = conn.createStatement(); //Rendeles tabla
		Statement stmt4 = conn.createStatement(); //Hozzavalo tabla
		Statement stmt5 = conn.createStatement(); //Tartalmaz tabla
		
		stmt1.execute("CREATE TABLE Pincer (pincerID int primary key, nev varchar(45), fizetes int check(fizetes > 200000), kor int check(kor >= 18), kezdes char(10) not null)");
		stmt2.execute("CREATE TABLE Asztal (asztalszam int primary key, ferohely int check(ferohely > 1), emelet int, foglalt int default 0, pincerAZ int, foreign key (pincerAZ) references Pincer(pincerID))");
		stmt3.execute("CREATE TABLE Rendeles (rendelesszam int primary key, etelDB int check(etelDB >= 0), italDB int check(italDB >= 0), etelar int check(etelar >= 0), italar int check(italar >= 0), asztalszam int, foreign key (asztalszam) references Asztal(asztalszam))");
		stmt4.execute("CREATE TABLE Hozzavalo (hozzavaloID int primary key, nev varchar(30), darabszam int check(darabszam >= 0), allergen varchar(20))");
		stmt5.execute("CREATE TABLE Tartalmaz (rendelesszam int, hozzavaloID int, foreign key (rendelesszam) references Rendeles(rendelesszam), foreign key (hozzavaloID) references Hozzavalo(hozzavaloID))");
		
		stmt1.close();
		stmt2.close();
		stmt3.close();
		stmt4.close();
		stmt5.close();
		
		System.out.println("Tablak letrehozva!\n");
	} //end createTables
	
	//Insert automatic
	public static void insertPincer(Connection conn) throws SQLException {
		Statement stmt = conn.createStatement();
		
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Pincer VALUES (1, 'Szabo Laszlo', 320000, 36, '2006-02-12')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Pincer VALUES (2, 'Kovacs Istvan', 230000, 27, '2010-05-19')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Pincer VALUES (3, 'Lukacs Balazs', 260000, 21, '2014-10-05')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Pincer VALUES (4, 'Almasi Kristof', 260100, 20, '2019-11-25')"));

		stmt.close();
		
		System.out.println("Pincer tabla feltoltve!\n");
	} //end insertPincer
	
	public static void insertAsztal(Connection conn) throws SQLException {
		Statement stmt = conn.createStatement();
		
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (1, 6, 0, 0, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (2, 2, 1, 1, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (3, 2, 1, 1, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (4, 10, 0, 0, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (5, 4, 0, 1, 2)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (6, 4, 1, 1, 2)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (7, 8, 0, 0, 2)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (8, 4, 0, 0, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (9, 2, 1, 1, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (10, 2, 1, 1, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Asztal VALUES (11, 8, 0, 1, 2)"));
		
		stmt.close();
		
		System.out.println("Asztal tabla feltoltve!\n");
	} //end insertAsztal
	
	public static void insertRendeles(Connection conn) throws SQLException {
		Statement stmt = conn.createStatement();
		
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (1, 2, 4, 3000, 500, 2)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (2, 2, 2, 5000, 600, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (3, 0, 4, 0, 800, 5)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (4, 4, 0, 2800, 0, 6)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (5, 0, 4, 0, 1300, 9)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (6, 2, 6, 10000, 750, 10)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Rendeles VALUES (7, 8, 12, 4600, 750, 11)"));
		
		stmt.close();
		
		System.out.println("Rendeles tabla feltoltve!\n");
	} //end insertRendeles
	
	public static void insertHozzavalo(Connection conn) throws SQLException {
		Statement stmt = conn.createStatement();
		
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (1, 'teszta', 20, 'gluten')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (2, 'tej', 20, 'laktoz')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (3, 'vaj', 32, 'laktoz')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (4, 'liszt', 32, 'gluten')"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (5, 'liszt', 15, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (6, 'marhahus', 23, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (7, 'csirkehus', 35, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (8, 'vadhus', 27, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (9, 'rizs', 36, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (10, 'burgonya', 21, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (11, 'alkohol', 70, NULL)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Hozzavalo VALUES (12, 'alkohol mentes', 70, NULL)"));
		
		stmt.close();
		
		System.out.println("Hozzavalo tabla feltoltve!\n");
	} //end insertHozzavalo
	
	public static void insertTartalmaz(Connection conn) throws SQLException {
		Statement stmt = conn.createStatement();
		
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 4)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 7)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 9)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (1, 12)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (2, 8)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (2, 10)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (2, 11)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (3, 11)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (3, 12)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (4, 1)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (4, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (4, 7)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (4, 9)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (4, 2)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (5, 11)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 12)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 11)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 10)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 8)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 5)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 9)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (6, 7)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 3)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 4)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 6)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 7)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 8)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 9)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 10)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 11)"));
		System.out.println("Inserted: " + stmt.executeUpdate("INSERT INTO Tartalmaz VALUES (7, 12)"));
		
		stmt.close();
		
		System.out.println("Tartalmaz tabla feltoltve!\n");
	} //end insertTartalmaz
	
	//Egyeb metodusok
	public static void addVegosszeg(Connection conn) throws SQLException {
		
		Statement stmt = conn.createStatement();
		stmt.executeUpdate("ALTER TABLE Rendeles ADD vegosszeg int");
		stmt.close();
		
		System.out.println("Vegosszeg mezo hozzaadva!\n");
	} //end addVegosszeg
	
	public static void updateVegosszeg(Connection conn) throws SQLException {	
		
		Statement stmt = conn.createStatement();
		stmt.executeUpdate("UPDATE Rendeles SET vegosszeg = (etelDB * etelar) + (italDB * italar)");
		stmt.close();
		
		System.out.println("Vegosszeg mezo frissitve!\n");
	} //end updateVegosszeg
	
	public static void deleteByIdFromPincer(Connection conn, int id) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("DELETE FROM Pincer WHERE pincerID=?");
		prstmt.setInt(1, id);
		System.out.println("Deleted waiter: "+ prstmt.executeUpdate());
		prstmt.close();
		
		System.out.println("Item deleted!\n");
	} //end deleteByIdFromPincer
	
	public static void getDBMetadata(Connection conn) throws SQLException {
		
		System.out.println("Driver verzi�: " + conn.getMetaData().getDriverVersion());
		String[] specifyTables= {"TABLE"};
		ResultSet rs= conn.getMetaData().getTables(null, null, "%", specifyTables);
		while(rs.next()) {
			System.out.println(rs.getString(3));
		}
		rs.close();
	} //end getDBMetadata
	
	public static void writeToFile(java.util.List<String> list, String path) {
		
        BufferedWriter out = null;
        try {
            File file = new File(path);
            out = new BufferedWriter(new FileWriter(file, true));
            for (Object s : list) {
                out.write((String) s);
                out.newLine();
            }
            out.flush();
            out.close();
            
            System.out.println("File-ba iras sikeres!\n");
        } catch (IOException e) {
        	System.out.println(e);
        }
    } //end writeToFile
	
	public static void selectAvgVegosszeg(Connection conn) throws SQLException {
		
		int avg = 0;
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT AVG(vegosszeg) AS atlagvego FROM Rendeles");
		while(rs.next()) {
			avg = rs.getInt("atlagvego");
        }
		stmt.close();
		rs.close();

		System.out.println("A rendelesek vegosszegenek atlaga: " + avg + " Ft");
	} //end selectAvgVegosszeg
	
	public static void getAllRendelesMeta(Connection conn) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT * FROM Rendeles");
		ResultSet rs = prstmt.executeQuery();	
		ResultSetMetaData rsmd = rs.getMetaData();
		System.out.println("Mezok szama rendeles eseten: " + rsmd.getColumnCount());
		for (int i = 1; i <= rsmd.getColumnCount(); i++) {
			System.out.println(rsmd.getColumnName(i)+":"+ rsmd.getColumnTypeName(i));
		}
		prstmt.close();
		rs.close();
	} //end getAllRendelesMeta
	
	public static void getAllPincerMeta(Connection conn) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT * FROM Pincer");
		ResultSet rs = prstmt.executeQuery();	
		ResultSetMetaData rsmd = rs.getMetaData();
		System.out.println("Mezok szama pincerek eseten: " + rsmd.getColumnCount());
		for (int i = 1; i <= rsmd.getColumnCount(); i++) {
			System.out.println(rsmd.getColumnName(i)+":"+ rsmd.getColumnTypeName(i));
		}
		prstmt.close();
		rs.close();
	} //end getAllRendelesMeta
	
	public static void selectAsztalRendeles(Connection conn) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT Asztal.asztalszam, Rendeles.vegosszeg FROM Asztal INNER JOIN Rendeles ON Asztal.asztalszam = Rendeles.asztalszam");
		ResultSet rs = prstmt.executeQuery();
		List <Lekerdezes1> adatokLista = new ArrayList<>();
		while(rs.next()) {
			Lekerdezes1 adat = new Lekerdezes1(rs.getInt("asztalszam"), rs.getInt("vegosszeg"));
			adatokLista.add(adat);
			System.out.println(adat);
		}
		
		prstmt.close();
		rs.close();
	} //end selectAsztalRendeles
	
	public static void selectMaxFizuPincerAsztalRendeles(Connection conn) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT Asztal.asztalszam, Asztal.ferohely, Asztal.emelet, Rendeles.rendelesszam, Rendeles.vegosszeg FROM Asztal INNER JOIN Rendeles ON Asztal.asztalszam = Rendeles.asztalszam WHERE Asztal.pincerAZ = (SELECT Pincer.pincerID FROM Pincer WHERE Pincer.fizetes = (SELECT MAX(fizetes) FROM Pincer))");
		ResultSet rs = prstmt.executeQuery();
		List <Lekerdezes2> adatokLista = new ArrayList<>();
		while(rs.next()) {
			Lekerdezes2 adat = new Lekerdezes2(rs.getInt("asztalszam"),rs.getInt("ferohely"), rs.getInt("emelet"),rs.getInt("rendelesszam"), rs.getInt("vegosszeg"));
			adatokLista.add(adat);
			System.out.println(adat);
		}
		
		prstmt.close();
		rs.close();
	} //end selectMaxFizuPincerAsztalRendeles
	
	public static void selectPincerByName(Connection conn,String nev) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT * FROM Pincer WHERE nev = ?");
		prstmt.setString(1, nev);
		ResultSet rs = prstmt.executeQuery();
		List<Pincer> pincerLista = new ArrayList<>();
		while(rs.next()) {
			Pincer pincer = new Pincer(rs.getInt("pincerID"),rs.getString("nev"),rs.getInt("fizetes"),rs.getInt("kor"),rs.getString("kezdes"));
			pincerLista.add(pincer);
			
			System.out.println(pincer);
		}
		rs.close();
		prstmt.close();
	} //end selectPincerByName
	
	public static void selectAsztalByFerohely(Connection conn,int ferohelyszam) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT * FROM Asztal WHERE ferohely = ?");
		prstmt.setInt(1, ferohelyszam);
		ResultSet rs = prstmt.executeQuery();
		List<Asztal> asztalLista = new ArrayList<>();
		while(rs.next()) {
			Asztal asztal = new Asztal(rs.getInt("asztalszam"),rs.getInt("ferohely"),rs.getInt("emelet"),rs.getInt("pincerAZ"));
			asztalLista.add(asztal);
			
			System.out.println(asztal);
		}
		rs.close();
		prstmt.close();
	} //end selectAsztalByFerohely
	
	public static void selectRendelesVegosszegByHozzavalo(Connection conn,String hozzavaloNeve) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("SELECT rendelesszam, vegosszeg FROM Rendeles WHERE rendelesszam IN (SELECT rendelesszam FROM Tartalmaz WHERE hozzavaloID = (SELECT hozzavaloID FROM Hozzavalo WHERE nev = ?))");
		prstmt.setString(1, hozzavaloNeve);
		ResultSet rs = prstmt.executeQuery();
		List<Lekerdezes3> adatokLista = new ArrayList<>();
		while(rs.next()) {
			Lekerdezes3 adat = new Lekerdezes3(rs.getInt("rendelesszam"),rs.getInt("vegosszeg"));
			adatokLista.add(adat);
			
			System.out.println(adat);
		}
		rs.close();
		prstmt.close();
	} //end selectRendelesVegosszegByHozzavalo
	
	public static void pincerFizetesModositas(Connection conn, int ujFiz, int pincerID) throws SQLException {
		
		PreparedStatement prstmt = conn.prepareStatement("UPDATE Pincer SET fizetes = ? WHERE pincerID = ?");
		prstmt.setInt(1, ujFiz);
		prstmt.setInt(2, pincerID);
		
		prstmt.executeUpdate();
		prstmt.close();
		
		System.out.println("Pincer fizetes updated!\n");
	} //end pincerFizetesModositas
	
	public static void pincerFizetesModUser(Connection conn) throws SQLException {
		
		int ujFiz = 200000, pincerID = 1;
		
		input = new Scanner(System.in);
		
		System.out.println("\nAdja meg a pincer azonositojat!");
		pincerID = input.nextInt();
		System.out.println("\nAdja meg a pincer uj fizeteset!");
		ujFiz = input.nextInt();
		
		PreparedStatement prstmt = conn.prepareStatement("UPDATE Pincer SET fizetes = ? WHERE pincerID = ?");
		
		if (ujFiz >= 200000 && pincerID > 0) {
			prstmt.setInt(1, ujFiz);
			prstmt.setInt(2, pincerID);
			prstmt.executeUpdate();
			System.out.println("Pincer fizetes updated user inputrol!\n");
		} else {
			System.out.println("\nHibas adat!");
		}
		
		prstmt.close();
	} //end pincerFizetesModUser
	
	public static void insertPincerFromUser(Connection conn) throws SQLException {
		int id = 0, fizetes = 200000, kor = 18;
		String nev = "", kezdes = "";
		
		PreparedStatement prstmt = conn.prepareStatement("INSERT INTO Pincer VALUES(?,?,?,?,?)");
		
		input = new Scanner(System.in);
		
		System.out.println("\nAdja meg a pincer azonositojat!");
		id = input.nextInt();
		input.nextLine();
		System.out.println("\nAdja meg a pincer nevet!");
		nev = input.nextLine();
		System.out.println("\nAdja meg a pincer fizeteset!");
		fizetes = input.nextInt();
		System.out.println("\nAdja meg a pincer korat!");
		kor = input.nextInt();
		input.nextLine();
		System.out.println("\nAdja meg mikor kezd a pincer (datum kotojelekkel)!");
		kezdes = input.nextLine();
		
		if (id > 0 && nev != "" && fizetes >= 200000 && kor >= 18 && kezdes != "") {
			prstmt.setInt(1, id);
			prstmt.setString(2, nev);
			prstmt.setInt(3, fizetes);
			prstmt.setInt(4, kor);
			prstmt.setString(5, kezdes);
			prstmt.execute();
			System.out.println("\nSikeres rekordfelvitel!");
		} else {
			System.out.println("Hibas adat(ok)!");
		}
		prstmt.close();
	} //end insertPincerFromUser
	
	public static void insertAsztalFromUser(Connection conn) throws SQLException {
		int id = 0, ferohely = 2, emelet = 0, foglalt = 0, pincerID = 1;

		PreparedStatement prstmt = conn.prepareStatement("INSERT INTO Asztal VALUES(?,?,?,?,?)");
		
		input = new Scanner(System.in);
		
		System.out.println("\nAdja meg az asztal azonositojat!");
		id = input.nextInt();
		System.out.println("\nAdja meg az asztal ferohelyet!");
		ferohely = input.nextInt();
		System.out.println("\nAdja meg az asztal melyik emeleten talalhato!");
		emelet = input.nextInt();
		System.out.println("\nAdja meg, hogy az asztal foglalt e! --> 0, ha szabad es 1, ha foglalt");
		foglalt = input.nextInt();
		System.out.println("\nAdja meg melyik pincer szolgaljon itt fel (ID)!");
		pincerID = input.nextInt();
		
		if (id > 0 && ferohely >= 2 && emelet >= 0 && foglalt == 0 || foglalt == 1 && pincerID > 0) {
			prstmt.setInt(1, id);
			prstmt.setInt(2, ferohely);
			prstmt.setInt(3, emelet);
			prstmt.setInt(4, foglalt);
			prstmt.setInt(5, pincerID);
			prstmt.execute();
			System.out.println("\nSikeres rekordfelvitel!");
		} else {
			System.out.println("Hibas adat(ok)!");
		}
		prstmt.close();
	} //end insertAsztalFromUser
	
	public static void insertRendelesFromUser(Connection conn) throws SQLException {
		int id = 0, etelDB = 0, italDB = 0, etelAr = 0, italAr = 0, asztalID = 0;

		PreparedStatement prstmt = conn.prepareStatement("INSERT INTO Rendeles VALUES(?,?,?,?,?,?,?)");
		
		input = new Scanner(System.in);
		
		System.out.println("\nAdja meg a rendeles azonositojat!");
		id = input.nextInt();
		System.out.println("\nAdja meg az etelek darabszamat!");
		etelDB = input.nextInt();
		System.out.println("\nAdja meg az italok darabszamat!");
		italDB = input.nextInt();
		System.out.println("\nAdja meg az etel(ek) arat!");
		etelAr = input.nextInt();
		System.out.println("\nAdja meg az ital(ok) arat!");
		italAr = input.nextInt();
		System.out.println("\nAdja meg melyik asztalhoz tartozik a rendeles (ID)!");
		asztalID = input.nextInt();
		
		if (id > 0 && etelDB >= 0 && italDB >= 0 && etelAr >= 0 && italAr >= 0 && asztalID > 0) {
			int vegosszeg = (etelDB * etelAr) + (italDB * italAr);
			prstmt.setInt(1, id);
			prstmt.setInt(2, etelDB);
			prstmt.setInt(3, italDB);
			prstmt.setInt(4, etelAr);
			prstmt.setInt(5, italAr);
			prstmt.setInt(6, asztalID);
			prstmt.setInt(7, vegosszeg);
			prstmt.execute();
			System.out.println("\nSikeres rekordfelvitel!");
		} else {
			System.out.println("Hibas adat(ok)!");
		}
		prstmt.close();
	} //end insertRendelesFromUser
	
	public static void insertHozzavaloFromUser(Connection conn) throws SQLException {
		int id = 0, db = 0;
		String nev = "", allergen = "";

		PreparedStatement prstmt = conn.prepareStatement("INSERT INTO Hozzavalo VALUES(?,?,?,?)");
		
		input = new Scanner(System.in);
		
		System.out.println("\nAdja meg a hozzavalo azonositojat!");
		id = input.nextInt();
		input.nextLine();
		System.out.println("\nAdja meg a hozzavalo nevet!");
		nev = input.nextLine();
		System.out.println("\nAdja meg, hogy hany darab van az adott hozzavalobol!");
		db = input.nextInt();
		input.nextLine();
		System.out.println("\nAdja meg, hogy a hozzavalo milyen allergent tartalmaz, ha nincs --> NULL");
		allergen = input.nextLine();
		
		if (id > 0 && nev != "" && db >= 0 && allergen != "") {
			prstmt.setInt(1, id);
			prstmt.setString(2, nev);
			prstmt.setInt(3, db);
			prstmt.setString(4, allergen);
			prstmt.execute();
			System.out.println("\nSikeres rekordfelvitel!");
		} else {
			System.out.println("Hibas adat(ok)!");
		}
		prstmt.close();
	} //end insertHozzavaloFromUser
	
	public static void insertTartalmazFromUser(Connection conn) throws SQLException {
		int rendelesszam = 0, hozzavaloID = 0;

		PreparedStatement prstmt = conn.prepareStatement("INSERT INTO Tartalmaz VALUES(?,?)");
		
		input = new Scanner(System.in);
		
		System.out.println("\nAdja meg a rendeles azonositojat!");
		rendelesszam = input.nextInt();
		System.out.println("\nAdja meg a hozzavalo azonositojat!");
		hozzavaloID = input.nextInt();
		
		if (rendelesszam >= 0 && hozzavaloID >= 0) {
			prstmt.setInt(1, rendelesszam);
			prstmt.setInt(2, hozzavaloID);
			prstmt.execute();
			System.out.println("\nSikeres rekordfelvitel!");
		} else {
			System.out.println("Hibas adat(ok)!");
		}
		prstmt.close();
	} //end insertTartalmazFromUser

} //end class