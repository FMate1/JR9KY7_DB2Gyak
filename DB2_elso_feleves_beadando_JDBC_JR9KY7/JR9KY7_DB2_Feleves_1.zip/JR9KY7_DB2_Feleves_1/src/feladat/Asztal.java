package feladat;

public class Asztal {
	
	private int asztalszam;
	private int ferohely;
	private int emelet;
	private int pincerAZ;
	
	public Asztal(int asztalszam, int ferohely, int emelet, int pincerAZ) {
		super();
		this.asztalszam = asztalszam;
		this.ferohely = ferohely;
		this.emelet = emelet;
		this.pincerAZ = pincerAZ;
	}

	public int getAsztalszam() {
		return asztalszam;
	}

	public void setAsztalszam(int asztalszam) {
		this.asztalszam = asztalszam;
	}

	public int getFerohely() {
		return ferohely;
	}

	public void setFerohely(int ferohely) {
		this.ferohely = ferohely;
	}

	public int getEmelet() {
		return emelet;
	}

	public void setEmelet(int emelet) {
		this.emelet = emelet;
	}

	public int getPincerAZ() {
		return pincerAZ;
	}

	public void setPincerAZ(int pincerAZ) {
		this.pincerAZ = pincerAZ;
	}

	@Override
	public String toString() {
		return "Asztal: asztalszam = " + asztalszam + ", ferohely = " + ferohely + ", emelet = " + emelet + ", pincerAZ = "
				+ pincerAZ + "\n";
	}
	
	

} //end class
